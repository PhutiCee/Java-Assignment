Student Number | Surname | Initials | Phone Number
---------------------------------------------------
202323251      | MAROKA  | M.C.     | 0636071420
202121116      | MASERAME| M.D.     | 0813107535
202363475      | MAOTO   | J.T.     | 0720170952
202248978      | MANGWALE| K.H.     | 0653531380
202246859      | MANGANYE| B.       | 0685811543
202344883      | MAROKANO| M.R.     | 0660706867
